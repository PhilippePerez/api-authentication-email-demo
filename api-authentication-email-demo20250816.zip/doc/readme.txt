Template

    Edit the following files

        > package.json

                "name": "portfolio-tuner"
                [...]
                "deploy": "scp -r ./dist/* root@root@server1.template-vue-frontend.com:/var/www/<DOMAIN NAME>"

        > index.html

                [...]
                <title>Welcome</title>

        > install.sh

                # 🔧 Configuration
                REMOTE_USER="root"
                REMOTE_HOST="template-vue-frontend.com"
                REMOTE_WEB_DIR="/var/www/template-vue-frontend.com"
                REMOTE_NGINX_CONF="/etc/nginx/sites-available/template-vue-frontend.com"

        > prod/nginx-config.txt

                [...]
                server_name template-vue-frontend  www.template-vue-frontend ;
                [...]
                root /var/www/template-vue-frontend.com;
                [...]
                error_log  /var/log/nginx/template-vue-frontend-error.log;
                access_log /var/log/nginx/template-vue-frontend-access.log;


    Edit PyCharm's config

        Set the correct Node.js version for the package.json scripts execution

            /home/philippe/.nvm/versions/node/v18.20.5/bin/npm run setup

        Start Verdaccion from the shell

        > verdaccio &

        Run npm install with 'setup' script


Dev

    Verdaccio

        Setup

                No Package Published Yet.
            To publish your first package just:

            1. Create user

            Or login

                npm login --registry http://localhost:4873/

                philippe / pp040773

            npm adduser --registry http://localhost:4873/

            2. Select registry

                npm set registry http://localhost:4873

            3. Publish

            npm publish --registry http://localhost:4873/

            4. Refresh this page

            Storage location:

                /home/philippe/.local/share/verdaccio/storage

            Back to normal registry

Deploy

    Nginx

        Install

            > sudo apt update
            > sudo apt install nginx -y

            Prevent Ngninx running as a service

                > sudo systemctl stop nginx
                > sudo systemctl disable nginx

        Run

            Manually

                > sudo nginx

            Manually with custom config

                > sudo nginx -c /path/to/nginx.conf

        Stop

            > sudo nginx -s stop

        Test

            > curl -I http://localhost

    Vue front end

NGinx HELLO WORLD

    Uninstall

        > sudo systemctl stop nginx
        > sudo apt remove --purge nginx nginx-common nginx-full -y
        > sudo apt autoremove -y
        > sudo rm -rf /etc/nginx
        > sudo rm -rf /var/log/nginx
        > sudo rm -rf /var/lib/nginx
        > sudo deluser nginx
        > nginx -v

        > sudo apt install nginx
        > systemctl status nginx
        > sudo nginx -t
        > sudo systemctl reload nginx
        > sudo cp -r /philippe/dev/projects/backgroundless_com/frontend/dist/* /var/www/html
        > open http://localhost/ with a web browser and check you see the web page

        Disable ( but don't delete ) default site

            > sudo rm   /etc/nginx/sites-enabled/default
            > sudo systemctl reload nginx

            You will see 'Unable to connect' accessing http://localhost/

            Let's copy the default config to tailor it to our needs.

            > sudo cp /etc/nginx/sites-available/default /etc/nginx/sites-available/trimbackground.com

            At this point we did nothing more than recreating the same configuration under a different name,
            following the good practice not to delete the default website in order to be able to revert our changes

            Now enable this configuration by creating a link which is like copy the file in the active configs ,
            but avoiding code duplication

            > sudo ln -s /etc/nginx/sites-available/trimbackground.com /etc/nginx/sites-enabled/

            Let's restart the server in order for our changes to be taken into account

            > sudo systemctl reload nginx

            Visiting http://localhost/ we can see our website , Hurray.
            That's enough for static content. But how about when our application need to access an API
            hosted on difference server , for instance Flask in a Python development environement.

            We need to tune the configuration for this to work

            # Proxy API requests to Flask running on port 5000
            location /api/ {
                proxy_pass http://127.0.0.1:5000/;
                proxy_set_header Host $host;
                proxy_set_header X-Real-IP $remote_addr;
                proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
                proxy_set_header X-Forwarded-Proto $scheme;
            }

            So let's edit the configuration file

            > sudo nano /etc/nginx/sites-available/trimbackground.com

            And insert the block in the server { ... } section

            > CTRL +X to exit , Type 'Y' to confirm you wish to save

            Ensure you did not corrupt the configuration by mistake

            > sudo nginx -t

                nginx: the configuration file /etc/nginx/nginx.conf syntax is ok
                nginx: configuration file /etc/nginx/nginx.conf test is successful

            Then restart the server

            > sudo systemctl reload nginx

            Let's add some error & access logs

            > sudo nano /etc/nginx/sites-available/trimbackground.com

            Then add in the     server {...} section the following lines

            error_log  /var/log/nginx/trimbackground-error.log;
            access_log /var/log/nginx/trimbackground-access.log;

            > CTRL +X to exit , Type 'Y' to confirm you wish to save

            Check you did not break the config

            > sudo nginx -t

            Restart Nginx

            > sudo systemctl reload nginx

            In a new shell type

            > tail -f  /var/log/nginx/trimbackground-access.log

            Now open

            > open http://localhost/ with a web browser and check you see the web page

            You should see some new logs each time you reload the page

            philippe@upwork-NUC8i5BEK:~$ tail -f  /var/log/nginx/trimbackground-access.log
            127.0.0.1 - - [08/Mar/2025:22:08:07 +0100] "GET / HTTP/1.1" 200 412 "-" "Mozilla/5.0 (X11; Linux x86_64; rv:131.0) Gecko/20100101 Firefox/131.0"
            127.0.0.1 - - [08/Mar/2025:22:08:07 +0100] "GET /assets/index-CR_yPXqH.css HTTP/1.1" 200 21947 "http://localhost/" "Mozilla/5.0 (X11; Linux x86_64; rv:131.0) Gecko/20100101 Firefox/131.0"
            127.0.0.1 - - [08/Mar/2025:22:08:12 +0100] "POST /api/remove-background HTTP/1.1" 502 166 "http://localhost/" "Mozilla/5.0 (X11; Linux x86_64; rv:131.0) Gecko/20100101 Firefox/131.0"
            127.0.0.1 - - [08/Mar/2025:22:08:57 +0100] "GET / HTTP/1.1" 200 412 "-" "Mozilla/5.0 (X11; Linux x86_64; rv:131.0) Gecko/20100101 Firefox/131.0"
            127.0.0.1 - - [08/Mar/2025:22:08:57 +0100] "GET /vite.svg HTTP/1.1" 200 1497 "http://localhost/" "Mozilla/5.0 (X11; Linux x86_64; rv:131.0) Gecko/20100101 Firefox/131.0"

            Set Up SSL with Let's Encrypt

                You can set up SSL for each domain using Let's Encrypt:

                > sudo apt install -y certbot python3-certbot-nginx

                Run the following command for each domain:

                > sudo certbot --nginx -d trimbackground.com -d www.trimbackground.com

                Similar output :

                     - Congratulations! Your certificate and chain have been saved at:
                       /etc/letsencrypt/live/trimbackground.com/fullchain.pem
                       Your key file has been saved at:
                       /etc/letsencrypt/live/trimbackground.com/privkey.pem
                       [...]

    Add SSL

        sudo certbot --nginx -d trimbackground.com -d www.trimbackground.com

        Saving debug log to /var/log/letsencrypt/letsencrypt.log
        Plugins selected: Authenticator nginx, Installer nginx
        Obtaining a new certificate
        Performing the following challenges:
        http-01 challenge for trimbackground.com
        http-01 challenge for www.trimbackground.com
        Using default address 80 for authentication.
        Using default address 80 for authentication.
        nginx: [warn] conflicting server name "vuewidgets.com" on 0.0.0.0:80, ignored
        nginx: [warn] conflicting server name "www.vuewidgets.com" on 0.0.0.0:80, ignored
        Waiting for verification...
        Cleaning up challenges
        nginx: [warn] conflicting server name "vuewidgets.com" on 0.0.0.0:80, ignored
        nginx: [warn] conflicting server name "www.vuewidgets.com" on 0.0.0.0:80, ignored
        Could not automatically find a matching server block for trimbackground.com. Set the `server_name` directive to use the Nginx installer.

        IMPORTANT NOTES:
         - Unable to install the certificate
         - Congratulations! Your certificate and chain have been saved at:
           /etc/letsencrypt/live/trimbackground.com/fullchain.pem
           Your key file has been saved at:
           /etc/letsencrypt/live/trimbackground.com/privkey.pem
           Your cert will expire on 2025-06-07. To obtain a new or tweaked
           version of this certificate in the future, simply run certbot again
           with the "certonly" option. To non-interactively renew *all* of
           your certificates, run "certbot renew"
        root@172-105-64-53:/opt/trimbackground_com/v1_0_0#


    Analytics

        simpleanalytics



philippe_perez2002@yahoo.fr
user :

pass : E48tF08sogeaD6_Dg
